<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>NEGOCIOS ELECTRÓNICOS</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/style_crud.css">
  </head>
  <body>

    <nav class="navbar navbar-dark bg-dark">
    <ul>
      <li><a class="active" href="menu.php">GAMORSWEB</a></li>
      <li><a href="promocional.php" class="nav-link">Publicidad</a></li>
      <li><a href="Registro.php" class="nav-link">Registrar Nuevos Productos</a></li>
      <li><a href="carrito.php" class="nav-link">Carrito</a></li>
      <li><a href="ventas.php" class="nav-link">Ventas</a></li>
      <li><a href="mapa.php" class="nav-link">Ubicacion</a></li>
    </ul>
    </nav>
